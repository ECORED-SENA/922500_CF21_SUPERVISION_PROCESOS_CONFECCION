function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5uLylQR3FFs":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

